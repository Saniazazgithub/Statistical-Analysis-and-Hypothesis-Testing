# Week 3 — Statistical Analysis and Hypothesis Testing

**Made by Sania Azaz**

Statistical analysis of the Mall Customers dataset using Python.

## Tests
- Welch independent-samples t-test: Gender vs Spending Score
- One-way ANOVA: Age Group vs Spending Score
- Chi-square test of independence: Gender vs Income Band

## Tools
Python, Pandas, SciPy, Seaborn, Matplotlib.

## Files
- Week_3_Statistical_Analysis_Report.docx
- Week_3_Technical_Coding_Documentation.docx
- week3_statistical_analysis.py
- Mall_Customers_Week3.csv
- Mall_Customers_Cleaned_Week3.csv
- visualizations/
- requirements.txt

## Statistical note
Alpha = 0.05. Results describe evidence in the observed sample and do not establish causation.
