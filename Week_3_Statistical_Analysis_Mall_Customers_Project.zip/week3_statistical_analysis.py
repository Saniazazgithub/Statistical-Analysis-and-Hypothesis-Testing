import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

df = pd.read_csv("Mall_Customers_Week3.csv")
if "index" in df.columns:
    df = df.drop(columns=["index"])
df.columns = ["CustomerID","Gender","Age","Annual Income (k$)","Spending Score (1-100)"]
df = df.drop_duplicates().dropna()

df["AgeGroup"] = pd.cut(df["Age"], bins=[17,25,35,50,70],
                        labels=["18-25","26-35","36-50","51-70"],
                        include_lowest=True)
df["IncomeBand"] = pd.cut(df["Annual Income (k$)"],
                          bins=[-float("inf"),40,70,100,float("inf")],
                          labels=["Low","Mid","Upper-mid","High"],
                          right=False)

# H1: Does spending score differ by gender?
# H0: Male and female mean spending scores are equal.
# H1: Male and female mean spending scores differ.
male = df.loc[df["Gender"]=="Male","Spending Score (1-100)"]
female = df.loc[df["Gender"]=="Female","Spending Score (1-100)"]
t_stat, p_t = stats.ttest_ind(male, female, equal_var=False)
print("Welch t-test:", t_stat, p_t)

# H2: Does spending score differ across age groups?
# H0: All age-group means are equal.
# H1: At least one age-group mean differs.
groups = [g["Spending Score (1-100)"].values
          for _, g in df.groupby("AgeGroup", observed=True)]
f_stat, p_anova = stats.f_oneway(*groups)
print("One-way ANOVA:", f_stat, p_anova)

# H3: Is gender associated with income band?
# H0: Gender and income band are independent.
# H1: Gender and income band are associated.
contingency = pd.crosstab(df["Gender"], df["IncomeBand"])
chi2, p_chi, dof, expected = stats.chi2_contingency(contingency)
print("Chi-square:", chi2, p_chi, "df:", dof)
print(contingency)

# Supporting visualizations
sns.set_theme(style="whitegrid")
sns.boxplot(data=df,x="Gender",y="Spending Score (1-100)")
sns.stripplot(data=df,x="Gender",y="Spending Score (1-100)",alpha=.4)
plt.savefig("01_spending_by_gender_ttest.png",dpi=180,bbox_inches="tight")
plt.close()

sns.boxplot(data=df,x="AgeGroup",y="Spending Score (1-100)")
sns.stripplot(data=df,x="AgeGroup",y="Spending Score (1-100)",alpha=.35)
plt.savefig("02_spending_by_age_anova.png",dpi=180,bbox_inches="tight")
plt.close()

sns.countplot(data=df,x="IncomeBand",hue="Gender")
plt.savefig("03_gender_income_chi_square.png",dpi=180,bbox_inches="tight")
plt.close()
